export default function Home() {
  return <h1>Conecta Trabalhador Frontend</h1>;
}